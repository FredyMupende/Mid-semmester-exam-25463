package com.rutare_clays.Rutare_Clays.repository;

import com.rutare_clays.Rutare_Clays.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer> {



}
