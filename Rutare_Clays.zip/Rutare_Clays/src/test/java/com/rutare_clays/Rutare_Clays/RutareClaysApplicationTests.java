package com.rutare_clays.Rutare_Clays;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RutareClaysApplicationTests {

	@Test
	void contextLoads() {
	}

}
