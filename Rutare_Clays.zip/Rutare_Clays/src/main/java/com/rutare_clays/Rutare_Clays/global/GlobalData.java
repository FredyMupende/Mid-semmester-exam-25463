package com.rutare_clays.Rutare_Clays.global;

import com.rutare_clays.Rutare_Clays.model.Product;

import java.util.ArrayList;
import java.util.List;

public class GlobalData {
    public static List<Product> cart;
    static {
        cart = new ArrayList<Product>();
    }
}
