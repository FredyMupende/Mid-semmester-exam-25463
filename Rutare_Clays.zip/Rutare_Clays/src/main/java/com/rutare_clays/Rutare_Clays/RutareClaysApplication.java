package com.rutare_clays.Rutare_Clays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RutareClaysApplication {

	public static void main(String[] args) {
		SpringApplication.run(RutareClaysApplication.class, args);
	}

}
