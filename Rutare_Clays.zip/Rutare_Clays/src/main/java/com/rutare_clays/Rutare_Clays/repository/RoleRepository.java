package com.rutare_clays.Rutare_Clays.repository;


import com.rutare_clays.Rutare_Clays.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Integer> {

}
